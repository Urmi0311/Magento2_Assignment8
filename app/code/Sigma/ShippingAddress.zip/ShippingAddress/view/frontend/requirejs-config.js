var config = {

    "map" : {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default' : 'Sigma_ShippingAddress/js/model/shipping-save-processor/default',
            'Magento_Checkout/template/shipping-information/address-renderer/default.html' : 'Sigma_ShippingAddress/template/shipping-information/address-renderer/default.html'
        }
    }
}
